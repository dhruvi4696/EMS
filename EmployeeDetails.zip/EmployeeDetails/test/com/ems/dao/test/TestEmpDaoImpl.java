package com.ems.dao.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.ems.bean.EmployeeBean;
import com.ems.dao.EmployeeDaoImpl;
import com.ems.exception.EmployeeException;

public class TestEmpDaoImpl 
{
	static EmployeeDaoImpl employeeDao;
	static EmployeeBean empBean;
	
	@BeforeClass
	public static void beforeClass()
	{
		employeeDao =new EmployeeDaoImpl();
		empBean = new EmployeeBean();
	}
	
	@Ignore
	@Test
	public void testAddEmployee() throws EmployeeException
	{
		empBean.setEmp_firstName("Vibha");
		empBean.setEmp_lastName("doshi");
		empBean.setEmp_contactNumber(909090);
		empBean.setEmp_email("abc@d.com");
		int id = employeeDao.addEmployeeDetails(empBean);
		assertTrue(id>0);
	}
	
	@Test
	public void testViewEmployeeById() throws EmployeeException
	{
		assertNotNull(employeeDao.viewEmpById(1));
	}
	
	@Test
	public void testViewEmpById1() throws EmployeeException {
		assertEquals("dhruvi", employeeDao.viewEmpById(1).getEmp_firstName());
	}
}
