package com.ems.dao.test;

import java.sql.Connection;

import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.*;

import com.ems.exception.EmployeeException;
import com.ems.util.DBConnection;

public class TestConnection 
{
	@Test
	public void testConnection() throws EmployeeException
	{
		System.out.println("establishing connection..");
		Connection con = DBConnection.getConnection();
		assertNotNull(con);
	}
	
	@Test(expected=EmployeeException.class)
	public void testConnectionFails() throws EmployeeException
	{
		System.out.println("testing exception for connection..");
		Connection con = DBConnection.getConnection();
		System.out.println("no exception found,thus testConnectionFails failed..");
	}
	
	
}
