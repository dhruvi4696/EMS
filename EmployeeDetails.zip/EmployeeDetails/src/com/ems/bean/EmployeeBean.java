package com.ems.bean;

import java.util.Date;

public class EmployeeBean 
{
	private int Emp_id;
	private String Emp_firstName ;
	private String Emp_lastName ;
	private long Emp_contactNumber ;
	private Date Emp_doj;
	private String Emp_email;
	
	public int getEmp_id() {
		return Emp_id;
	}
	public void setEmp_id(int emp_id) {
		Emp_id = emp_id;
	}
	public String getEmp_firstName() {
		return Emp_firstName;
	}
	public void setEmp_firstName(String emp_firstName) {
		Emp_firstName = emp_firstName;
	}
	public String getEmp_lastName() {
		return Emp_lastName;
	}
	public void setEmp_lastName(String emp_lastName) {
		Emp_lastName = emp_lastName;
	}
	public long getEmp_contactNumber() {
		return Emp_contactNumber;
	}
	public void setEmp_contactNumber(long emp_contactNumber) {
		Emp_contactNumber = emp_contactNumber;
	}
	public Date getEmp_doj() {
		return Emp_doj;
	}
	public void setEmp_doj(Date emp_doj) {
		Emp_doj = emp_doj;
	}
	public String getEmp_email() {
		return Emp_email;
	}
	public void setEmp_email(String emp_email) {
		Emp_email = emp_email;
	}
	
	@Override
	public String toString() {
		return "EmployeeBean [Emp_id=" + Emp_id + ", Emp_firstName="
				+ Emp_firstName + ", Emp_lastName=" + Emp_lastName
				+ ", Emp_contactNumber=" + Emp_contactNumber + ", Emp_doj="
				+ Emp_doj + ", Emp_email=" + Emp_email + "]";
	}

}
