package com.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ems.dao.EmployeeDaoImpl;
import com.ems.util.DBConnection;
import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

public class EmployeeDaoImpl implements EmployeeDao
{
	Logger logger = Logger.getLogger(EmployeeDaoImpl.class);
	
	public EmployeeDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
	public int generateEmployeeId()
	{
		logger.debug("Generating new id");
		int id=0;
		Connection  con = null;
		String str= "select Employeeid_seq.nextval from dual";
		try {
			con=DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			id=rs.getInt(1);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return id;
	}
	
	
	@Override
	public int addEmployeeDetails(EmployeeBean bean) throws EmployeeException 
	{
		int id=0;
		Connection con= null;
		String cmd="insert into Employee_tbl(Emp_id,Emp_firstName, Emp_lastName, Emp_contactNumber,Emp_doj, Emp_email) values(?,?,?,?,sysdate,?)";
		
		try {
			
			con=DBConnection.getConnection();
			logger.warn("connected to database!");
			 id=generateEmployeeId();
			PreparedStatement ps = con.prepareStatement(cmd);
			
			ps.setInt(1,id);
			ps.setString(2,bean.getEmp_firstName());
			ps.setString(3, bean.getEmp_lastName());
			ps.setLong(4,bean.getEmp_contactNumber());
			ps.setString(5,bean.getEmp_email());
			
			ps.executeUpdate();
			logger.info("employee details added");
		}
		catch (Exception e) 
		{
			logger.error("add emp exception");
			throw new EmployeeException("unable to insert");
		}
		return id;
	}

	@Override
	public EmployeeBean viewEmpById(int viewId) throws EmployeeException 
	{
		Connection con= null;
		Statement stmt =null;
		EmployeeBean bean= new EmployeeBean();
		
		try {
			con=DBConnection.getConnection();
			logger.warn("connected to database!");
			String cmd="select Emp_id,Emp_firstName,Emp_lastName,Emp_contactNumber,Emp_doj,Emp_email from Employee_tbl where Emp_id ="+ viewId;
			 stmt =con.createStatement();
			
			 ResultSet result =stmt.executeQuery(cmd);
			 if(result.next())
				{
				 	bean.setEmp_id(result.getInt(1));
					bean.setEmp_firstName(result.getString(2));
					bean.setEmp_lastName(result.getString(3));
					bean.setEmp_contactNumber(result.getLong(4));
					bean.setEmp_doj(result.getDate(5));
					bean.setEmp_email(result.getString(6));
				}
			 logger.info("view emp success!");
		}
		catch (Exception e) 
		{
			logger.error("view emp exception"+e);
			throw new EmployeeException("unable to view by id!");
		}
		return bean;	

	}

}
