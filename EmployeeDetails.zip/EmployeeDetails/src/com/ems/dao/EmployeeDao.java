package com.ems.dao;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

public interface EmployeeDao 
{
	public int addEmployeeDetails(EmployeeBean bean) throws EmployeeException;
	public EmployeeBean viewEmpById(int empid) throws EmployeeException;
}
