package com.ems.pl;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;
import com.ems.service.EmployeeService;
import com.ems.service.EmployeeServiceImpl;

public class EmployeeDetailsMain
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int ch;
		do
		{
		System.out.println("1.add employee details");
		System.out.println("2.view all employee details");
		System.out.println("3.exit");
		
		int choice = sc.nextInt();
		

		switch(choice)
		{
		case 1:
			System.out.println("enter employee first name: ");
			String firstName = sc.next();
			System.out.println("enter employee last name: ");
			String lastName = sc.next();
			System.out.println("enter employee contact number: ");
			Long phoneNumber = sc.nextLong();
			System.out.println("enter employee email id: ");
			String emailId= sc.next();
			
			EmployeeBean bean = new EmployeeBean();
			bean.setEmp_firstName(firstName);
			bean.setEmp_lastName(lastName);
			bean.setEmp_contactNumber(phoneNumber);
			bean.setEmp_email(emailId);
			
			EmployeeService service = new EmployeeServiceImpl();
			
			try {
				boolean b=service.validateDetails(bean);
				if(b==true)
				{
					int n = service.addEmployeeDetails(bean);
					System.out.println("employee added! id = "+n);
				} 
				else
				{
					throw new EmployeeException("enter valid detail! ");
				}
			}
			catch (EmployeeException e) 
			{	
				e.printStackTrace();
			}
			break;
		
		case 2:
			System.out.println("enter id you want to view : ");
			int viewId = sc.nextInt();
			EmployeeService service2 = new EmployeeServiceImpl();
			
			try
			{
				EmployeeBean bean1  =service2.viewEmpById(viewId);
				System.out.println("the details of id : "+viewId+"\n");
				System.out.println("employee's id              : "+bean1.getEmp_id());
				System.out.println("employee's first name      : "+bean1.getEmp_firstName());
				System.out.println("employee's last name       : "+bean1.getEmp_lastName());
				System.out.println("employee's contact number  : "+bean1.getEmp_contactNumber());
				System.out.println("employee's date of joining : "+bean1.getEmp_doj());
				System.out.println("employee's email-id        : "+bean1.getEmp_email()+"\n");
			}
			catch (EmployeeException e) 
			{
				e.printStackTrace();
			}
			break;
			
		case 3:
			break;
			
		default:
			System.out.println("Enter valid choice as 1, 2 or 3 !");
			break;
		}
		
		System.out.println("Do you want to continue?");
		System.out.println("1.yes\n2.no");
		ch = sc.nextInt();
		
		}while (ch!=2);
	}
}
	

