package com.ems.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.ems.bean.EmployeeBean;
import com.ems.dao.EmployeeDao;
import com.ems.dao.EmployeeDaoImpl;
import com.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService
{

	private EmployeeDao employeedao = new EmployeeDaoImpl();
	private EmployeeBean bean = new EmployeeBean();
	@Override
	public int addEmployeeDetails(EmployeeBean bean) throws EmployeeException 
	{
		int id= employeedao.addEmployeeDetails(bean);
		return id;
	}

	@Override
	public  EmployeeBean viewEmpById(int viewId) throws EmployeeException 
	{
		EmployeeBean bean = new EmployeeBean();
		bean = employeedao.viewEmpById(viewId);
		return bean;
	}

	@Override
	public boolean validateDetails(EmployeeBean bean) throws EmployeeException 
	{
		/*EmployeeServiceImpl service = new EmployeeServiceImpl();
		
		boolean validate = true;
		
		if(service.validateEmail(bean)==true && service.validateName(bean)==true && service.validatePhone(bean)==true )
		{
			validate = true;
		}
		else{
			validate = false;}
		return validate;*/
		
		boolean validate = false;
		List<String> validationErrors = new ArrayList<String>();
		
		if(!(validateName(bean) ))
		{
			validationErrors.add("\n Employee Name Should Be In Alphabets and minimum 4 characters long and max 15 characters long! \n");
		}
		
		if(!(validatePhone(bean.getEmp_contactNumber())))
		{
			validationErrors.add("\nContact number should be exact 10 digits! \n");
		}
	
		if(!(validateEmail(bean.getEmp_email())))
		{
			validationErrors.add("\n Not a valid email id \n" );
		}
		
		if(!validationErrors.isEmpty())
		{
			throw new EmployeeException(validationErrors +"");
		}
		else
		{
			validate = true;
		}
		return validate;
}
		/*
		boolean validate = true;
		if(bean.getEmp_firstName()!=" " && bean.getEmp_lastName()!=" "&& bean.getEmp_email()!=" " )
		{
			Pattern pattern =Pattern.compile("[A-Z][a-z]{3,14}");
			Matcher matcher= pattern.matcher(bean.getEmp_firstName());
			Matcher matcher1= pattern.matcher(bean.getEmp_lastName());

			Pattern pattern1 =Pattern.compile("[1-9][0-9]{9}");
			Matcher matcher2= pattern1.matcher(String.valueOf(bean.getEmp_contactNumber()));

			Pattern pattern2 =Pattern.compile("\\b[\\w.%-]+@[-.\\w]+\\.[A-Za-z]{2,4}\\b");
			Matcher matcher3= pattern2.matcher(bean.getEmp_email());
			
			if(matcher.matches()&&matcher1.matches()&&matcher3.matches()&&matcher2.matches())
			{
				validate=true;
			}
			else
			{
				validate = false;
			}
		}
		else
		{
			validate=false;
		}*/
	

	@Override
	public boolean validateName(EmployeeBean bean) throws EmployeeException 
	{
		boolean validate;
		Pattern pattern =Pattern.compile("[A-Z][A-Za-z]{3,14}");
		Matcher matcher= pattern.matcher(bean.getEmp_firstName());
		Matcher matcher1= pattern.matcher(bean.getEmp_lastName());
		if(matcher.matches()&&matcher1.matches())
		{
			validate=true;
		}
		else
		{
			validate = false;
		}
		return validate;
	}

	@Override
	public boolean validatePhone(long phone) throws EmployeeException 
	{
		Pattern pattern =Pattern.compile("[1-9][0-9]{9}");
		Matcher matcher= pattern.matcher(String.valueOf(phone));
		return matcher.matches();
		
	}

	@Override
	public boolean validateEmail(String email) throws EmployeeException 
	{
		Pattern pattern =Pattern.compile("\\b[\\w.%-]+@[-.\\w]+\\.[A-Za-z]{2,4}\\b");
		Matcher matcher= pattern.matcher(email);
		return matcher.matches();
	}	
}
