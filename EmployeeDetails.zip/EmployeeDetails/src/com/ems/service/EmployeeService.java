package com.ems.service;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

public interface EmployeeService 
{               
	public int addEmployeeDetails(EmployeeBean bean) throws EmployeeException;
	public EmployeeBean viewEmpById(int empid) throws EmployeeException;
	public boolean validateDetails(EmployeeBean bean) throws EmployeeException;
	public boolean validateName(EmployeeBean bean) throws EmployeeException;
	public boolean validatePhone(long phone) throws EmployeeException;
	public boolean validateEmail(String email) throws EmployeeException;
}


