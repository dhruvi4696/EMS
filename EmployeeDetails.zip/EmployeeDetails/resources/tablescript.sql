
SQL> CREATE TABLE Employee_tbl (Emp_id NUMBER(6) PRIMARY KEY, Emp_firstName VARC
HAR2(15),Emp_lastName VARCHAR2(15), Emp_contactNumber NUMBER(10), Emp_doj DATE,E
mp_email VARCHAR2(15));

Table created.

SQL> CREATE SEQUENCE Employeeid_seq START WITH 1;

Sequence created.
